
// The function is called every time when an order comes in or an order gets processed
// The current order queue is stored in the variable 'orders'

function updateVisualization(orders) {
	console.log(orders);

}