var dataMarriages = [
    //TODO: Fill in the data
];

var dataBusiness = [
    //TODO: Fill in the data
];

var matrix;



// TODO: Load data 



// Initialize the matrix visualization
document.getElementById('select-order-type').onchange = function () {
    matrix.updateVis(this.value);
}