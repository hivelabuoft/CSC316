/*
 * Matrix - Object constructor function
 * @param _parentElement 					-- the HTML element in which to draw the visualization
 * @param _dataFamilyAttributes		-- attributes for the 16 Florentine families
 * @param _dataMarriage						-- marriage data stored in a symmetric adjacency matrix
 * @param _dataBusiness						-- business relations stored in a symmetric adjacency matrix
 */

Matrix = function (_parentElement, _dataFamilyAttributes, _dataMarriages, _dataBusiness) {
    // TODO: Store the input parameters

    // TODO: Initialize the visualization
    
};


/*
 * Initialize visualization (static content; e.g. SVG area, axes)
 */

Matrix.prototype.initVis = function () {
    // TODO: Implement
};


/*
 * Data wrangling
 */

Matrix.prototype.wrangleData = function () {
    // TODO: Implement
};


/*
 * The drawing function
 */

Matrix.prototype.updateVis = function (orderingType) {
    var vis = this;

    // Update sorting
    // TODO: Implement


    // Draw matrix rows (and y-axis labels)
    // TODO: Implement

    // ENTER
    var rowsGroups = dataJoin.enter()
        .append("g")
        .attr("class", "matrix-row");

    // ENTER
    rowsGroups.append("text")
        .attr("class", "matrix-label matrix-row-label")
        .attr("x", -10)
        .attr("y", vis.cellHeight / 2)
        .attr("dy", ".35em")
        .attr("text-anchor", "end")
        .text(function (d, index) {
            return d.name;
        })
        .merge(dataJoin.select(".matrix-row-label"));   // merge ENTER + UPDATE (row labels)

    rowsGroups.merge(dataJoin)  // merge ENTER + UPDATE groups
        .style('opacity', 0.5)
        .transition()
        .duration(1000)
        .style('opacity', 1)
        .attr("transform", function (d, index) {
            return "translate(0," + (vis.cellHeight + vis.cellPadding) * index + ")";
        });


    // Draw marriage triangles
    // TODO: Implement


    // Draw business triangles
    // TODO: Implement

    // Draw x-axis labels
    // TODO: Implement
};